/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, Lock, ArrowRight, Loader2, ShieldCheck, Info } from 'lucide-react';
import { generateBrandingImage } from './services/gemini';

export default function App() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [brandingImage, setBrandingImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleGenerateImage = async () => {
    setIsGenerating(true);
    setError(null);
    try {
      const prompt = "A professional branding image for the City of Laredo Public Health Department. The image should be inspired by their official logo: a shield-shaped emblem featuring a medical cross at its center, using a sophisticated color palette of navy blue and muted gold/tan. The background should be a clean, modern medical or office environment, or a stylized abstract representation of community health. High quality, professional photography or high-end vector illustration style.";
      const imageUrl = await generateBrandingImage(prompt);
      if (imageUrl) {
        setBrandingImage(imageUrl);
      } else {
        setError("Failed to generate image. Please try again.");
      }
    } catch (err) {
      console.error(err);
      setError("An error occurred while generating the image.");
    } finally {
      setIsGenerating(false);
    }
  };

  useEffect(() => {
    handleGenerateImage();
  }, []);

  return (
    <div className="min-h-screen bg-[#F5F5F5] flex items-center justify-center p-4 font-sans">
      <div className="max-w-5xl w-full bg-white rounded-[32px] shadow-xl overflow-hidden flex flex-col md:flex-row min-h-[600px]">
        
        {/* Left Side: Login Form */}
        <div className="flex-1 p-8 md:p-12 flex flex-col justify-center">
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
                <ShieldCheck className="text-white w-5 h-5" />
              </div>
              <span className="text-xs font-bold uppercase tracking-widest text-emerald-600">Secure Portal</span>
            </div>
            <h1 className="text-4xl font-light tracking-tight text-zinc-900 mb-2">
              Laredo <span className="font-semibold text-blue-900">Public Health</span>
            </h1>
            <p className="text-zinc-500 text-sm">Welcome back. Please enter your credentials to access the Public Health Portal.</p>
          </div>

          <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
            <div className="space-y-2">
              <label className="text-xs font-semibold uppercase tracking-wider text-zinc-400 ml-1">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400 w-5 h-5" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full pl-12 pr-4 py-4 bg-zinc-50 border border-zinc-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all text-zinc-900"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-semibold uppercase tracking-wider text-zinc-400 ml-1">Password</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400 w-5 h-5" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-12 pr-4 py-4 bg-zinc-50 border border-zinc-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all text-zinc-900"
                />
              </div>
            </div>

            <div className="flex items-center justify-between text-sm">
              <label className="flex items-center gap-2 cursor-pointer group">
                <input type="checkbox" className="w-4 h-4 rounded border-zinc-300 text-emerald-600 focus:ring-emerald-500" />
                <span className="text-zinc-500 group-hover:text-zinc-700 transition-colors">Remember me</span>
              </label>
              <a href="#" className="text-emerald-600 font-medium hover:text-emerald-700 transition-colors">Forgot password?</a>
            </div>

            <button className="w-full bg-zinc-900 text-white py-4 rounded-2xl font-semibold flex items-center justify-center gap-2 hover:bg-zinc-800 transition-all group active:scale-[0.98]">
              Sign In
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </form>

          <div className="mt-8 pt-8 border-t border-zinc-100 flex items-center justify-between">
            <p className="text-zinc-400 text-xs">© 2024 City of Laredo Public Health Department</p>
            <div className="flex gap-4">
              <a href="#" className="text-zinc-400 hover:text-zinc-600 transition-colors"><Info className="w-4 h-4" /></a>
            </div>
          </div>
        </div>

        {/* Right Side: AI Branding Image */}
        <div className="flex-1 bg-zinc-900 relative overflow-hidden flex items-center justify-center min-h-[400px] md:min-h-full">
          <AnimatePresence mode="wait">
            {isGenerating ? (
              <motion.div
                key="loading"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex flex-col items-center gap-4 text-white/60"
              >
                <Loader2 className="w-12 h-12 animate-spin text-emerald-500" />
                <p className="text-sm font-medium tracking-widest uppercase">Generating Branding...</p>
              </motion.div>
            ) : brandingImage ? (
              <motion.div
                key="image"
                initial={{ opacity: 0, scale: 1.1 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8 }}
                className="absolute inset-0"
              >
                <img
                  src={brandingImage}
                  alt="City of Laredo Health Department Branding"
                  className="w-full h-full object-cover opacity-80"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-transparent to-transparent" />
                <div className="absolute bottom-12 left-12 right-12">
                  <motion.div
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.5 }}
                  >
                    <h2 className="text-3xl font-light text-white mb-2">Dedicated to <span className="font-semibold">Your Health</span></h2>
                    <p className="text-white/60 text-sm max-w-md">Serving the community of Laredo with excellence, compassion, and innovation.</p>
                  </motion.div>
                </div>
                
                <button 
                  onClick={handleGenerateImage}
                  className="absolute top-8 right-8 bg-white/10 hover:bg-white/20 backdrop-blur-md text-white text-[10px] uppercase tracking-widest px-4 py-2 rounded-full border border-white/20 transition-all"
                >
                  Regenerate Image
                </button>
              </motion.div>
            ) : error ? (
              <div className="text-center p-8">
                <p className="text-red-400 text-sm mb-4">{error}</p>
                <button 
                  onClick={handleGenerateImage}
                  className="px-6 py-2 bg-emerald-600 text-white rounded-xl text-sm font-medium"
                >
                  Retry Generation
                </button>
              </div>
            ) : null}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
